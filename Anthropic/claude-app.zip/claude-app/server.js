const express = require('express');
const Anthropic = require('@anthropic-ai/sdk');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory conversation storage
const conversations = new Map();

function getOrCreateConversation(id) {
  if (!conversations.has(id)) {
    conversations.set(id, { id, title: 'New Chat', messages: [], createdAt: Date.now() });
  }
  return conversations.get(id);
}

// GET all conversations
app.get('/api/conversations', (req, res) => {
  const list = Array.from(conversations.values())
    .sort((a, b) => b.createdAt - a.createdAt)
    .map(({ id, title, createdAt, messages }) => ({
      id, title, createdAt, messageCount: messages.length
    }));
  res.json(list);
});

// GET single conversation
app.get('/api/conversations/:id', (req, res) => {
  const conv = conversations.get(req.params.id);
  if (!conv) return res.status(404).json({ error: 'Not found' });
  res.json(conv);
});

// DELETE conversation
app.delete('/api/conversations/:id', (req, res) => {
  conversations.delete(req.params.id);
  res.json({ ok: true });
});

// POST: send message (streaming)
app.post('/api/chat', async (req, res) => {
  const { conversationId, message, model, apiKey, systemPrompt } = req.body;

  if (!apiKey) return res.status(400).json({ error: 'API key required' });
  if (!message) return res.status(400).json({ error: 'Message required' });

  const client = new Anthropic({ apiKey });
  const conv = getOrCreateConversation(conversationId || `conv_${Date.now()}`);

  // Add user message
  conv.messages.push({ role: 'user', content: message });

  // Auto-title from first message
  if (conv.messages.length === 1) {
    conv.title = message.slice(0, 60) + (message.length > 60 ? '…' : '');
  }

  // Set up SSE
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  // Send conversation ID first
  res.write(`data: ${JSON.stringify({ type: 'conv_id', id: conv.id })}\n\n`);

  let fullResponse = '';

  try {
    const streamParams = {
      model: model || 'claude-opus-4-5',
      max_tokens: 8096,
      messages: conv.messages.map(m => ({ role: m.role, content: m.content })),
    };
    if (systemPrompt) streamParams.system = systemPrompt;

    const stream = await client.messages.stream(streamParams);

    for await (const chunk of stream) {
      if (chunk.type === 'content_block_delta' && chunk.delta.type === 'text_delta') {
        fullResponse += chunk.delta.text;
        res.write(`data: ${JSON.stringify({ type: 'text', text: chunk.delta.text })}\n\n`);
      }
    }

    // Save assistant response
    conv.messages.push({ role: 'assistant', content: fullResponse });
    res.write(`data: ${JSON.stringify({ type: 'done', conversationId: conv.id })}\n\n`);
    res.end();

  } catch (err) {
    res.write(`data: ${JSON.stringify({ type: 'error', error: err.message })}\n\n`);
    res.end();
    // Remove the user message if it failed
    conv.messages.pop();
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Claude App running at http://localhost:${PORT}`));
