# Claude App — Local AI Interface

A self-hosted Claude.ai-style interface powered by the Anthropic Node.js SDK.

## Features
- 💬 Full chat interface with markdown rendering
- 🧠 Conversation memory (per-session, multiple conversations)
- 🤖 Model selector (Opus, Sonnet, Haiku)
- ⚡ Streaming responses
- 🔧 System prompt editor
- 🔑 API key stored locally in browser (never logged server-side)
- ⛔ Stop generation mid-stream

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Start the server
```bash
npm start
```

Or with live-reload during development:
```bash
npm run dev
```

### 3. Open in browser
```
http://localhost:3000
```

### 4. Enter your API key
Click **"Set API Key"** in the top right and enter your Anthropic API key (`sk-ant-...`).
Your key is saved in `localStorage` — it never touches the server logs.

## Requirements
- Node.js 18+
- An Anthropic API key (https://console.anthropic.com)

## Notes
- Conversations are stored **in memory** while the server runs. Restarting the server clears them.
- Want persistence? Replace the `Map` in `server.js` with SQLite or a JSON file.
- The server runs on port `3000` by default. Change with `PORT=8080 npm start`.
